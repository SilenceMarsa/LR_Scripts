Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Sec-Fetch-Dest", "document");

	web_add_auto_header("Sec-Fetch-Mode", "navigate");

	web_add_auto_header("Sec-Fetch-Site", "none");

	web_add_auto_header("Priority", "u=0, i");

	web_revert_auto_header("Priority");

	web_add_auto_header("DNT", "1");

	web_add_header("Sec-Fetch-User", "?1");

	web_add_auto_header("Sec-GPC", "1");

	web_add_header("Upgrade-Insecure-Requests", "1");
	
	web_url("authorize", 
		"URL=https://dev-boomq.pflb.ru/authorize", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/static/media/Montserrat-Regular.3db65dc4b858f0fed4fb.woff", "Referer=https://dev-boomq.pflb.ru/static/css/main.64a4c65b.css", ENDITEM, 
		"Url=/static/media/logo.f5ae2890e77693e018920d4ad41c643c.svg", ENDITEM, 
		"Url=/static/media/loading.b59fa25397e07d75b9ac55ace151e625.svg", ENDITEM, 
		"Url=/static/media/Montserrat-Medium.d42dad28f6470e5162c2.woff", "Referer=https://dev-boomq.pflb.ru/static/css/main.64a4c65b.css", ENDITEM, 
		"Url=/static/media/Montserrat-Bold.180ba33d8de7dcfe80a0.woff", "Referer=https://dev-boomq.pflb.ru/static/css/main.64a4c65b.css", ENDITEM, 
		"Url=/static/media/Montserrat-SemiBold.197213592de7a2a62e06.woff", "Referer=https://dev-boomq.pflb.ru/static/css/main.64a4c65b.css", ENDITEM, 
		LAST);
	
	lr_start_transaction("UC_01_Login");

	web_add_header("Origin", 
		"https://dev-boomq.pflb.ru");

	web_add_auto_header("Sec-Fetch-Dest", "empty");

	web_add_auto_header("Sec-Fetch-Mode", "cors");

	web_add_auto_header("Sec-Fetch-Site", "same-origin");

	web_add_header("X-Client-Date", 
		"2024-09-17T17:56:21.928Z");

	lr_think_time(12);

	// ����������� ������ ������ ��� ����������
	web_set_max_html_param_len("262144");

	// ������ �������� ����
	web_reg_save_param_ex(
	    "ParamName=cookie",
	    "LB=boomq_auth=",
	    "RB=;",
	    "NotFound=ERROR",
	    LAST);
	
	web_submit_data("login", 
		"Action=https://dev-boomq.pflb.ru/auth-srv/login", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"Referer=https://dev-boomq.pflb.ru/authorize", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value={login}", ENDITEM,
		"Name=password", "Value={pass}", ENDITEM, 
		"Name=submit", "Value=Login", ENDITEM, 
		EXTRARES, 
		"Url=../static/media/en.b1acfc6b06bfe6e29bfbfc06d09d8177.svg", "Referer=https://dev-boomq.pflb.ru/account", ENDITEM, 
		LAST);
	
	web_add_cookie("boomq_auth={cookie}; DOMAIN=dev-boomq.pflb.ru");

	web_url("config.json", 
		"URL=https://dev-boomq.pflb.ru/config.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);
	
	web_add_auto_header("Authorization", "Bearer {cookie}");

	web_url("user", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/user", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_url("modelSchema", 
		"URL=https://dev-boomq.pflb.ru/project-srv/modelSchema", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("identityProvider", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/identityProvider", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_save_param_json(
		"ParamName=teamId",
		"QueryString=$..id",
		SEARCH_FILTERS,
		LAST);
	
	web_url("team", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/team?size=2", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_save_param("boomq_auth_second",
	    "LB=boomq_auth\=",
	    "RB=\n",
	    "Search=Headers",
	    LAST);
	
	web_url("teamContext", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/teamMember/teamContext?teamId={teamId}", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);
	
	web_remove_auto_header("Authorization", LAST);
  
	web_add_auto_header("Authorization", "Bearer {boomq_auth_second}");
	
	web_url("testRunner", 
		"URL=https://dev-boomq.pflb.ru/test-runner-srv/testRunner?sort=id,desc", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);
	
	web_add_header("Origin", 
		"https://dev-boomq.pflb.ru");
	
	web_add_header("Content-Type", "application/json");
	
	web_custom_request("user_2", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/user", 
		"Method=PUT", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"Body={\"email\":\"Nikolaev_4_{numbers}@test.test\",\"id\":1913,\"language\":\"EN\",\"notificationEnabled\":false}", 
		LAST);

	web_url("13", 
		"URL=https://dev-boomq.pflb.ru/auth-srv/team/{teamId}", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/new-test", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC_01_Login",LR_AUTO);

	lr_start_transaction("UC_02_go_Report");

	web_add_header("Origin", 
		"https://dev-boomq.pflb.ru");

	web_add_header("Priority", 
		"u=0");

	lr_think_time(9);

	web_add_header("Content-Type", "application/json");
	
	web_custom_request("search", 
		"URL=https://dev-boomq.pflb.ru/report-srv/report/search", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/reports", 
		"Snapshot=t12.inf", 
		"Mode=HTML",  
		"Body={\"pagination\":{\"pageNumber\":0,\"pageSize\":9},\"sort\":[{\"field\":\"CREATED_AT\",\"direction\":\"DESC\"}]}", 
		LAST);

	lr_end_transaction("UC_02_go_Report",LR_AUTO);

	lr_think_time(16);

	lr_start_transaction("UC_03_Create_Report");

	web_url("test", 
		"URL=https://dev-boomq.pflb.ru/test-srv/test?sort=createDate,desc&displayState=FINISHED", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/reports/new", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"https://dev-boomq.pflb.ru");

	web_add_header("Priority", 
		"u=0");

	lr_think_time(77);

	web_reg_save_param_json(
		"ParamName=report_id",
		"QueryString=$..id",
		SEARCH_FILTERS,
		LAST);
	
	web_add_header("Content-Type", "application/json");
	
	web_custom_request("report", 
		"URL=https://dev-boomq.pflb.ru/report-srv/report", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/reports/new", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"BodyBinary={\"labelSet\":[],\"name\":\"\\xD0\\x9E\\xD1\\x82\\xD1\\x87\\xD1\\x91\\xD1\\x82 {numbers}\",\"testIdSet\":[],\"reportContent\":{\"charts\":[],\"reportMarkup\":\"[{\\\\\"id\\\\\":\\\\\"loyc25lGlc\\\\\",\\\\\"type\\\\\":\\\\\"header\\\\\",\\\\\"data\\\\\":{\\\\\"text\\\\\":\\\\\"\\xD0\\x97\\xD0\\xB0\\xD0\\xB3\\xD0\\xBE\\xD0\\xBB\\xD0\\xBE\\xD0\\xB2\\xD0\\xBE\\xD0\\xBA \\xD0\\xBE\\xD1\\x82\\xD1\\x87\\xD1\\x91\\xD1\\x82\\xD0\\xB0 {numbers}\\\\\",\\\\\"level\\\\\":1}},{\\\\\"id\\\\\":\\\\\""
		"eU1rf-_BbA\\\\\",\\\\\"type\\\\\":\\\\\"paragraph\\\\\",\\\\\"data\\\\\":{\\\\\"text\\\\\":\\\\\"\\xD0\\xA1\\xD1\\x83\\xD0\\xBF\\xD0\\xB5\\xD1\\x80! \\xD0\\xA1\\xD1\\x83\\xD0\\xBF\\xD0\\xB5\\xD1\\x80! \\xD0\\xA1\\xD1\\x83\\xD0\\xBF\\xD0\\xB5\\xD1\\x80!\\\\\"}},{\\\\\"id\\\\\":\\\\\"z_wp165xQ-\\\\\",\\\\\"type\\\\\":\\\\\"table\\\\\",\\\\\"data\\\\\":{\\\\\"withHeadings\\\\\":false,\\\\\"content\\\\\":[[\\\\\"1\\\\\",\\\\\"2\\\\\",\\\\\"3\\\\\"],[\\\\\"4\\\\\",\\\\\"5\\\\\",\\\\\"6\\\\\"]]}}]\",\""
		"tables\":[]}}", 
		LAST);

	web_url("1158", 
		"URL=https://dev-boomq.pflb.ru/report-srv/report/{report_id}", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/reports/{report_id}", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_url("content", 
		"URL=https://dev-boomq.pflb.ru/report-srv/report/{report_id}/content", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/reports/{report_id}", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_url("test_2", 
		"URL=https://dev-boomq.pflb.ru/test-srv/test?sort=createDate,desc&displayState=FINISHED", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://dev-boomq.pflb.ru/account/reports/{report_id}", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC_03_Create_Report",LR_AUTO);
	
	return 0;
}